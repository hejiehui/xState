﻿using com.xross.tools.xstate;
using System;

namespace xstate.test
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                StateMachineFactory f = StateMachineFactory.load("new_state_machine.xstate");
                StateMachine sm = f.create("state machine 2");

                print(sm);
                sm.notify(new Event("event1"));

                print(sm);
                sm.notify(new Event("event2"));

                print(sm);
                sm.notify(new Event("event3"));

                print(sm);
                Console.Read();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
                Console.Read();
            }
        }

        static void print(StateMachine sm)
        {
            Console.WriteLine("Current state Id: " + sm.getCurrentState().getId());
            Console.WriteLine("Is ended: " + sm.isEnded());
        }
    }
}
