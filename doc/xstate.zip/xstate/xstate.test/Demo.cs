﻿using com.xross.tools.xstate;
using System;

namespace xstate.test
{
    public class DemoEntryAction : EntryAction
    {
        public void enter(string targetStateId, Event e)
        {
            Console.WriteLine("I'm EntryAction.");
        }
    }

    public class DemoExitAction : ExitAction
    {
        public void exit(string sourceStateId, Event e)
        {
            Console.WriteLine("I'm ExitAction");
        }
    }

}
