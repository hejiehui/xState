using System;
using System.Collections.Generic;

namespace com.xross.tools.xstate
{
    public class State
    {
        private String id;
        private String reference;
        private StateType type;
        private String description;
        private IDictionary<String, Transition> outputs = new Dictionary<String, Transition>();
        private EntryAction entryAction;
        private ExitAction existAction;

        public State(
                String id,
                StateType type,
                String description,
                EntryAction entryAction,
                ExitAction existAction,
                IList<Transition> transitions)
        {
            this.id = id;
            this.type = type;
            this.description = description;
            this.entryAction = NullAction.guardWith(entryAction);
            this.existAction = NullAction.guardWith(existAction);

            if (transitions == null)
                return;

            foreach (Transition trans in transitions)
            {
                if (outputs.ContainsKey(trans.getEventId()))
                    throw new SystemException(String.Format("Duplicate event: {0} found for state: {1}", trans.getEventId(), id));
                outputs.Add(trans.getEventId(), trans);
            }
        }

        public State(
                String id,
                String reference,
                StateType type,
                String description,
                EntryAction entryAction,
                ExitAction existAction,
                IList<Transition> transitions)
            : this(id, type, description, entryAction, existAction, transitions)
        {
            this.reference = reference;
        }

        public String getId()
        {
            return id;
        }

        public StateType getType()
        {
            return type;
        }

        public String getDescription()
        {
            return description;
        }

        public String getReference()
        {
            return reference;
        }

        public void setReference(String reference)
        {
            this.reference = reference;
        }

        public ICollection<String> getAcceptableEvents()
        {
            return outputs.Keys;
        }

        public Boolean isAcceptable(Event e)
        {
            return outputs.ContainsKey(e.getId());
        }

        public Transition getTransition(Event e)
        {
            Transition t = null;
            outputs.TryGetValue(e.getId(), out t);
            return t;
        }

        public void enter(Event e)
        {
            entryAction.enter(id, e);
        }

        public void exist(Event e)
        {
            existAction.exit(id, e);
        }
    }
}