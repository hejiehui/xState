using System;

namespace com.xross.tools.xstate
{
    public class Transition
    {
        private String eventId;
        private TransitAction transitionAction;
        private String sourceStateId;
        private String targetStateId;

        public Transition(
                String eventId,
                TransitAction transitionAction,
                String sourceStateId,
                String targetStateId)
        {
            this.eventId = eventId;
            this.transitionAction = NullAction.guardWith(transitionAction);
            this.sourceStateId = sourceStateId;
            this.targetStateId = targetStateId;
        }

        public String getEventId()
        {
            return eventId;
        }
        public void transit(Event e)
        {
            transitionAction.transit(sourceStateId, targetStateId, e);
        }

        public String getSourceStateId()
        {
            return sourceStateId;
        }

        public String getTargetStateId()
        {
            return targetStateId;
        }
    }
}