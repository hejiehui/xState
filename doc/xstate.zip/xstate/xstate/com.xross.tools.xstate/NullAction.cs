using System;

namespace com.xross.tools.xstate
{
    public class NullAction : EntryAction, ExitAction, TransitAction, TransitionGuard
    {
        public static readonly NullAction instance = new NullAction();

        public static T guardWith<T>(T action)
        {
            if (action == null)
                return (T)Convert.ChangeType(instance, typeof(T));  //return (T)instance;
            return action;
        }

        public void transit(String sourceStateId, String targetStateId, Event e) { }

        public void exit(String sourceStateId, Event e) { }

        public void enter(String targetStateId, Event e) { }

        public Boolean isTransitAllowed(String sourceId, String targetId, Event e) { return true; }
    }
}