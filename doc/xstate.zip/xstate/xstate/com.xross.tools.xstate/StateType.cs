namespace com.xross.tools.xstate
{
    public enum StateType
    {
        start, normal, end
    }
}