using com.xross.tools.xstate.def;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Reflection;
using System.Xml;

namespace com.xross.tools.xstate
{
    /**
     * TODO revise factory
     * @author Jerry He
     *
     */
    public class StateMachineFactory : StateMachineDiagramConstants
    {
        private String name;
        private String description;
        private IDictionary<String, StateMachineDef> stateMachines;

        private StateMachineFactory(
                String name,
                String description,
                IDictionary<String, StateMachineDef> stateMachines)
        {
            this.name = name;
            this.description = description;
            this.stateMachines = stateMachines;
        }

        public String getName()
        {
            return name;
        }

        public String getDescription()
        {
            return description;
        }

        public ICollection<String> getStateMachineNames()
        {
            return stateMachines.Keys;
        }

        public String getStateMachineDescription(String name)
        {
            if (!stateMachines.ContainsKey(name))
                return null;
            return stateMachines[name].getDescription();
        }

        public StateMachine create(String stateMachineName)
        {
            try
            {
                StateMachineDef def = null;
                stateMachines.TryGetValue(stateMachineName, out def);
                if (def == null)
                    throw new InvalidOperationException(String.Format("Can not found state machine definition for name: {0}", stateMachineName));

                return def.create();
            }
            catch (TypeLoadException)	//ClassNotFoundException
            {
                throw;
            }
            catch (Exception)	//InstantiationException, IllegalAccessException, ClassNotFoundException
            {
                throw;
            }
        }

        public static StateMachineFactory load(Uri url)
        {
            try
            {
                WebRequest request = WebRequest.Create(url);
                Stream stream = null;
                using (WebResponse response = request.GetResponse())
                {
                    stream = response.GetResponseStream();
                }

                return load(stream);
            }
            catch (IOException)
            {
                throw;
            }
            catch (Exception)	//SAXException, IOException, ParserConfigurationException
            {
                throw;
            }
        }

        /**
         * It will first check model file from file path, if it does not exist, it will try classpath then. 
         * @param path
         * @return
         * @throws Exception
         */
        public static StateMachineFactory load(String path)
        {
            try
            {
                Stream input;
                if (File.Exists(path))
                    input = new FileStream(path, FileMode.Open, FileAccess.Read);
                else
                {
                    Assembly classLoader = Assembly.GetExecutingAssembly();
                    if (classLoader == null)
                    {
                        classLoader = typeof(StateMachineFactory).Assembly;
                    }
                    String directory = Path.GetDirectoryName(classLoader.Location);
                    String filePath = Path.Combine(directory, path);
                    input = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                }

                return load(input);
            }
            catch (FileNotFoundException)
            {
                throw;
            }
            catch (IOException)
            {
                throw;
            }
            catch (Exception)	//throws FileNotFoundException, SAXException, IOException, ParserConfigurationException
            {
                throw;
            }
        }

        public static StateMachineFactory load(FileInfo model)
        {
            try
            {
                return load(model.OpenRead());
            }
            catch (Exception)	//throws FileNotFoundException, SAXException, IOException, ParserConfigurationException 
            {
                throw;
            }
        }

        public static StateMachineFactory load(Stream input)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(input);
                StateMachineFactory def = getFromDocument(doc);
                input.Close();
                return def;
            }
            catch (Exception e)
            {	//throws SAXException, IOException, ParserConfigurationException 
                if (input != null)
                    try
                    {
                        input.Close();
                    }
                    catch (Exception)
                    {

                    }
                Debug.WriteLine(e.StackTrace);	//e.printStackTrace();
            }

            return null;
        }

        private static StateMachineFactory getFromDocument(XmlDocument doc)
        {
            XmlElement root = doc.DocumentElement;

            String name = getChildNodeText(root, NAME);
            String description = getChildNodeText(root, DESCRIPTION);

            return new StateMachineFactory(name, description, readMachines(getChildNode(root, STATE_MACHINES)));
        }

        private static IDictionary<String, StateMachineDef> readMachines(XmlNode machinesNode)
        {
            XmlNodeList machines = machinesNode.ChildNodes;
            IDictionary<String, StateMachineDef> machineMap = new Dictionary<String, StateMachineDef>();
            for (int i = 0; i < machines.Count; i++)
            {
                StateMachineDef def = readMachine(machines.Item(i));
                if (!machineMap.ContainsKey(def.getName()))
                    machineMap.Add(def.getName(), null);
                machineMap[def.getName()] = def;
            }
            return machineMap;
        }

        private static StateMachineDef readMachine(XmlNode machineNode)
        {
            StateMachineDef machine = new StateMachineDef();
            machine.setName(getChildNodeText(machineNode, NAME));
            machine.setDescription(getChildNodeText(machineNode, DESCRIPTION));

            XmlNode statesNode = getChildNode(machineNode, STATES);
            XmlNode eventsNode = getChildNode(machineNode, EVENTS);
            XmlNode transitionsNode = getChildNode(machineNode, TRANSITIONS);

            machine.setEventDefs(readEvents(eventsNode));
            machine.setStateDefs(readStates(statesNode));
            machine.setTansitionDefs(linkState(machine, transitionsNode));

            return machine;
        }

        private static IList<StateDef> readStates(XmlNode statesNode)
        {
            XmlNodeList states = statesNode.ChildNodes;
            IList<StateDef> nodes = new List<StateDef>();
            for (int i = 0; i < states.Count; i++)
            {
                nodes.Add(readState(states.Item(i)));
            }
            return nodes;
        }

        private static StateDef readState(XmlNode stateNode)
        {
            StateDef node = createStateNode(stateNode);
            node.setId(getAttribute(stateNode, ID));
            node.setDescription(getChildNodeText(stateNode, DESCRIPTION));

            node.setReference(getChildNodeText(stateNode, REFERENCE));
            node.setEntryActionDef(new ActionDef(getChildNodeText(stateNode, ENTRY_ACTION)));
            node.setExitActionDef(new ActionDef(getChildNodeText(stateNode, EXIT_ACTION)));

            return node;
        }

        private static StateDef createStateNode(XmlNode stateNode)
        {
            StateDef def = new StateDef();
            StateType type;
            if (stateNode.Name.Equals(START_STATE))
                type = StateType.start;
            else
                if (stateNode.Name.Equals(END_STATE))
                    type = StateType.end;
                else
                    type = StateType.normal;
            def.setType(type);
            return def;
        }
        private static IList<TransitionDef> linkState(StateMachineDef machineDef, XmlNode transitionsNode)
        {
            XmlNodeList transitions = transitionsNode.ChildNodes;
            IDictionary<String, EventDef> events = new Dictionary<String, EventDef>();

            foreach (EventDef e in machineDef.getEventDefs())
            {
                if (!events.ContainsKey(e.getId()))
                    events.Add(e.getId(), null);
                events[e.getId()] = e;
            }

            IList<TransitionDef> transitionDefs = new List<TransitionDef>();
            for (int i = 0; i < transitions.Count; i++)
            {
                XmlNode node = transitions.Item(i);
                String sourceId = getAttribute(node, SOURCE_ID);
                String targetId = getAttribute(node, TARGET_ID);
                EventDef e = null;
                events.TryGetValue(getAttribute(node, EVENT_ID), out e);
                TransitionDef transition = new TransitionDef(sourceId, targetId);
                transition.setEventDef(e);
                transition.setTransitActionDef(new ActionDef(getAttribute(node, TRANSIT_ACTION)));
                transitionDefs.Add(transition);
            }

            return transitionDefs;
        }

        private static IList<EventDef> readEvents(XmlNode eventsNode)
        {
            XmlNodeList events = eventsNode.ChildNodes;
            IList<EventDef> eventList = new List<EventDef>();
            for (int i = 0; i < events.Count; i++)
            {
                XmlNode eventNode = events.Item(i);
                EventDef e = new EventDef();
                e.setId(getAttribute(eventNode, ID));
                e.setDescription(eventNode.InnerText);
                eventList.Add(e);
            }
            return eventList;
        }

        private static String getChildNodeText(XmlNode node, String childName)
        {
            XmlNode child = getChildNode(node, childName);
            if (child == null)
                return null;

            return child.InnerText;
        }

        private static XmlNode getChildNode(XmlNode node, String name)
        {
            XmlNodeList children = node.ChildNodes;
            XmlNode found = null;
            for (int i = 0; i < children.Count; i++)
            {
                if (!children.Item(i).Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                    continue;
                found = children.Item(i);
                break;
            }
            return found;
        }

        private static String getAttribute(XmlNode node, String attributeName)
        {
            XmlNamedNodeMap map = node.Attributes;
            for (int i = 0; i < map.Count; i++)
                if (attributeName.Equals(map.Item(i).Name))
                    return map.Item(i).Value;

            return null;
        }
    }
}