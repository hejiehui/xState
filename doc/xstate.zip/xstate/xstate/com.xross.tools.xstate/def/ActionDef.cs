using System;
using System.Collections.Generic;
using System.Linq;

namespace com.xross.tools.xstate.def
{
    public class ActionDef
    {
        private String implName;

        public ActionDef(String implName)
        {
            this.implName = implName;
        }

        public String getImplName()
        {
            return implName;
        }

        public void setImplName(String implName)
        {
            this.implName = implName;
        }

        public Object create()
        {
            try
            {
                if (implName == null || implName.Length == 0)
                    return NullAction.instance;

                Type type = null;
                types.TryGetValue(implName.ToLower(), out type);
                return Activator.CreateInstance(type);   //Class.forName(implName).newInstance()
            }
            catch (TypeLoadException)    //ClassNotFoundException
            {
                throw;
            }
            catch (Exception)   //throws InstantiationException, IllegalAccessException, ClassNotFoundException
            {
                throw;
            }
        }

        private IDictionary<String, Type> _types = null;

        private IDictionary<String, Type> types
        {
            get
            {
                if (_types == null)
                {
                    _types = new Dictionary<String, Type>();
                    var assemblies = AppDomain.CurrentDomain.GetAssemblies().Where(p => !p.GlobalAssemblyCache);

                    if (assemblies == null)
                        return _types;

                    foreach (var assembly in assemblies)
                    {
                        Type[] definedTypes = assembly.GetTypes();
                        if (definedTypes == null || definedTypes.Length == 0)
                            continue;

                        foreach (var type in definedTypes)
                        {
                            String typeName = type.FullName.ToLower();
                            if (!_types.ContainsKey(typeName))
                                _types.Add(typeName, type);
                        }
                    }
                }

                return _types;
            }
        }
    }
}