using System;
using System.Collections.Generic;

namespace com.xross.tools.xstate.def
{
    public class StateMachineDef
    {
        private String name;
        private String description;
        private IList<StateDef> stateDefs;
        private IList<EventDef> eventDefs;
        private IList<TransitionDef> tansitionDefs;

        public String getName()
        {
            return name;
        }

        public void setName(String name)
        {
            this.name = name;
        }

        public String getDescription()
        {
            return description;
        }

        public void setDescription(String description)
        {
            this.description = description;
        }

        public IList<StateDef> getStateDefs()
        {
            return stateDefs;
        }

        public void setStateDefs(IList<StateDef> stateDefs)
        {
            this.stateDefs = stateDefs;
        }

        public IList<EventDef> getEventDefs()
        {
            return eventDefs;
        }

        public void setEventDefs(IList<EventDef> eventDefs)
        {
            this.eventDefs = eventDefs;
        }

        public IList<TransitionDef> getTansitionDefs()
        {
            return tansitionDefs;
        }

        public void setTansitionDefs(IList<TransitionDef> tansitionDefs)
        {
            this.tansitionDefs = tansitionDefs;
        }

        public StateMachine create()
        {
            try
            {
                IDictionary<String, IList<Transition>> transitions = new Dictionary<String, IList<Transition>>();

                foreach (TransitionDef tansitionDef in tansitionDefs)
                {
                    String sourceId = tansitionDef.getSourceId();
                    if (!transitions.ContainsKey(sourceId))
                        transitions.Add(sourceId, new List<Transition>());
                    IList<Transition> outputs = null;
                    transitions.TryGetValue(sourceId, out outputs);

                    Transition transition = new Transition(
                            tansitionDef.getEventDef().getId(),
                            (TransitAction)tansitionDef.getTransitActionDef().create(),
                            tansitionDef.getSourceId(),
                            tansitionDef.getTargetId());

                    outputs.Add(transition);
                }

                IList<State> states = new List<State>();
                foreach (StateDef stateDef in stateDefs)
                {
                    IList<Transition> list = null;
                    transitions.TryGetValue(stateDef.getId(), out list);

                    states.Add(new State(
                            stateDef.getId(),
                            stateDef.getType(),
                            stateDef.getDescription(),
                            (EntryAction)stateDef.getEntryActionDef().create(),
                            (ExitAction)stateDef.getExitActionDef().create(),
                            list));
                }

                return new StateMachine(name, description, states, NullAction.instance);
            }
            catch (TypeLoadException)	//ClassNotFoundException
            {
                throw;
            }
            catch (Exception ex) // throws InstantiationException, IllegalAccessException, ClassNotFoundException 
            {
                throw;
            }
        }
    }
}