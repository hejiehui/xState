using System;
using System.Collections.Generic;

namespace com.xross.tools.xstate
{
    public class StateMachine
    {
        private String name;
        private String description;
        private TransitionGuard gaurd;
        private State currentState;
        private State startState;
        private IList<State> states;

        public StateMachine(String name, String description, IList<State> states, TransitionGuard gaurd)
        {
            this.name = name;
            this.description = description;
            this.gaurd = gaurd;
            this.states = states;
            verify();
        }

        public void verify()
        {
            foreach (State state in states)
            {
                if (state.getType() == StateType.start)
                    if (startState == null)
                        startState = state;
                    else
                        throw new InvalidOperationException("Found multiple start states. There should only one start state for a state machine.");
            }

            currentState = startState;
        }

        public String getName()
        {
            return name;
        }

        public String getDescription()
        {
            return description;
        }

        // TODO
        public ICollection<String> getEventIds()
        {
            return null;
        }

        public State getCurrentState()
        {
            return currentState;
        }

        //	public void start() {
        //		if(currentState != null)
        //			throw new IllegalStateException(String.format("State machine: %s is already started. Currnet state id is %s", name, currentState.getId()));
        //		
        //		currentState = startState;
        //	}
        //	
        private State findState(String id)
        {
            foreach (State state in states)
            {
                if (state.getId().Equals(id, StringComparison.OrdinalIgnoreCase))
                    return state;
            }

            throw new InvalidOperationException(String.Format("The given state id: {0} is not found", id));
        }

        public Boolean isStarted()
        {
            if (currentState == null)
                return false;

            return currentState.getType() != StateType.end;
        }

        public Boolean notify(Event e)
        {
            State source = currentState;

            if (!currentState.isAcceptable(e))
                return false;

            Transition trans = currentState.getTransition(e);
            State target = findState(trans.getTargetStateId());

            if (!gaurd.isTransitAllowed(source.getId(), target.getId(), e))
                return false;

            currentState.exist(e);
            trans.transit(e);
            target.enter(e);
            currentState = target;

            return true;
        }

        public Boolean isEnded()
        {
            if (currentState == null)
                return false;

            return currentState.getType() == StateType.end;
        }

        /*
         * Reset the state machine
         */
        public void reset()
        {
            if (isEnded())
                throw new InvalidOperationException(String.Format("State machine: %s is already ended. Can not be reset.", name));

            currentState = startState;
        }

        /**
         * Restore to given state
         * @param id
         */
        public void restore(String id)
        {
            if (isEnded())
                throw new InvalidOperationException(String.Format("State machine: %s is already ended. Can not be restored.", name));

            currentState = findState(id);
        }
    }
}