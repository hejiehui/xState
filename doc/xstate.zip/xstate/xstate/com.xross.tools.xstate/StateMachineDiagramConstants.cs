using System;

namespace com.xross.tools.xstate
{
    public abstract class StateMachineDiagramConstants
    {
        String STATE_MACHINE_DIAGRAM = "state_machine_diagram";
        internal static String STATE_MACHINES = "state_machines";
        String STATE_MACHINE = "state_machine";
        internal static String ID = "id";
        internal static String NAME = "name";
        internal static String DESCRIPTION = "description";
        internal static String REFERENCE = "reference";

        internal static String STATES = "states";
        String STATE = "state";
        internal static String START_STATE = "start";
        internal static String END_STATE = "end";

        String X_LOC = "x_loc";
        String Y_LOC = "y_loc";

        internal static String ENTRY_ACTION = "entry_action";
        internal static String EXIT_ACTION = "exit_action";

        internal static String EVENTS = "events";
        String EVENT = "event";

        internal static String TRANSITIONS = "transitions";
        String TRANSITION = "transition";
        internal static String EVENT_ID = "event_id";
        internal static String TRANSIT_ACTION = "transit_action";
        internal static String SOURCE_ID = "source_id";
        internal static String TARGET_ID = "target_id";

    }
}