using System;

namespace com.xross.tools.xstate
{
    public interface TransitionGuard
    {
        Boolean isTransitAllowed(String sourceId, String targetId, Event e);
    }
}