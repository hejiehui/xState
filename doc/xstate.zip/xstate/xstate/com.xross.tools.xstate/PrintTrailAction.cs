using System;

namespace com.xross.tools.xstate
{
    public class PrintTrailAction : EntryAction, ExitAction, TransitAction, TransitionGuard
    {
        public static readonly PrintTrailAction instance = new PrintTrailAction();

        public void transit(String sourceStateId, String targetStateId, Event e)
        {
            Console.WriteLine(String.Format("Transit from {0} to {1} on {2}", sourceStateId, targetStateId, e.getId()));
        }

        public void exit(String sourceStateId, Event e)
        {
            Console.WriteLine(String.Format("Exit from {0} on {1}", sourceStateId, e.getId()));
        }

        public void enter(String targetStateId, Event e)
        {
            Console.WriteLine(String.Format("Enter into {0} on {1}", targetStateId, e.getId()));
        }

        public Boolean isTransitAllowed(String sourceId, String targetId, Event e) { return true; }
    }
}